#include <stdio.h>

int main() {
    int son;

    printf("Son kiriting: ");
    scanf("%d", &son);

    for (int i = 0; i < son; i++) {

        for (int j = 0; j < son - i; j++) {
            printf("%c", 'A' + j);
        }

        for (int k = 0; k < 2 * i; k++) {
            printf(" ");
        }


        for (int j = son - i - 1; j >= 0; j--) {
            printf("%c", 'A' + j);
        }

        printf("\n");
    }

    return 0;
}
