#include <stdio.h>

int main()
{
    int son;

        printf("sonni kiriting");
        scanf("%d", &son);

        for(int i=1; i<=son; i++)
        {
            for(int j=1; j<=son; j++)
            {
                if(i==son || i==1 || j==1 || son==j)
                {
                    printf("1");
                }else{
                    printf("0");
                }

            }
            printf("\n");
        }

    return 0;
}
