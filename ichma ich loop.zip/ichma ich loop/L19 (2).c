#include <stdio.h>

int main()
{
    int son;

        printf("sonni kiriting");
        scanf("%d", &son);

        for(int i=0; i<=son; i++)
        {
            for(int j=0; j<i; j++)
            {
                    printf("%c", 'A' + j);
                }
                 printf("\n");
            }



    return 0;
}
