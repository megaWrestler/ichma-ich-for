#include <stdio.h>

int main()
{
    int son;

        printf("sonni kiriting");
        scanf("%d", &son);

        for(int i=son; i>=1; i--)
        {
            for(int j=i; j<son+1; j++)
            {
                printf(" ");
            }
            for(int g=1; g<=i; g++)
            {
                printf("* ");
            }
            printf("\n");
        }
        for(int i=2; i<=son; i++)
        {
            for(int j=i; j<son+1; j++)
            {
                printf(" ");
            }
            for(int g=1; g<=i; g++)
            {
                printf("* ");
            }
            printf("\n");
        }

    return 0;
}
