#include <stdio.h>

int main()
{
    int son;

        printf("sonni kiriting");
        scanf("%d", &son);

        for(int i=1; i<=son; i++)
        {
            for(int j=i; j<son+1; j++)
            {
                printf("  ");
            }
            for(int g=1; g<=i*2-1; g++)
            {
                printf("* ");
            }
            printf("\n");
        }
    return 0;
}
