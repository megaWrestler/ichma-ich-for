#include <stdio.h>

int main()
{
    int son;

        printf("son kiriting");
        scanf("%d", &son);

        for(int i=son; i>=0; i--)
        {
            for(int j=1; j<=i; j++)
            {
                printf("* ");
            }
            printf("\n");
        }
    return 0;
}
