#include <stdio.h>

int main()
{
    int son;

        printf("son kiriting");
        scanf("%d", &son);

        for(int i=son; i>=1; i--)
        {
            for(int j=i; j<=son+1; j++)
            {
                printf(" ");
            }
            for(int h=1; h<=i; h++)
            {
                printf("* ");
            }
            printf("\n");
        }
    return 0;
}
